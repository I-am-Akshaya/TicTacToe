document.addEventListener('DOMContentLoaded', () => {
    const board = document.getElementById('board');
    const resultScreen = document.getElementById('result-screen');
    const resultMessage = document.getElementById('result-message');
    const newGameBtn = document.getElementById('new-game-btn');

    let cells = [];
    let currentPlayer = 'X';
    let gameWon = false;

    initializeBoard();

    function initializeBoard() {
        cells = Array.from({ length: 9 }, (_, index) => createCell(index));
        resultScreen.classList.add('hidden');
    }

    function createCell(index) {
        const cell = document.createElement('div');
        cell.classList.add('cell');
        cell.addEventListener('click', () => handleCellClick(index));
        board.appendChild(cell);
        return cell;
    }

    function handleCellClick(index) {
        if (!gameWon && !cells[index].textContent) {
            cells[index].textContent = currentPlayer;
            if (checkForWinner()) {
                displayResult(`Player ${currentPlayer} wins!`);
            } else if (cells.every(cell => cell.textContent)) {
                displayResult("It's a draw!");
            } else {
                currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
            }
        }
    }

    function checkForWinner() {
        const winPatterns = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
            [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
            [0, 4, 8], [2, 4, 6]             // Diagonals
        ];

        return winPatterns.some(pattern => (
            cells[pattern[0]].textContent &&
            cells[pattern[0]].textContent === cells[pattern[1]].textContent &&
            cells[pattern[1]].textContent === cells[pattern[2]].textContent
        ));
    }

    function displayResult(message) {
        resultMessage.textContent = message;
        resultScreen.classList.remove('hidden');
        newGameBtn.classList.remove('hidden');
    }

    newGameBtn.addEventListener('click', () => {
        resetGame();
    });

    function resetGame() {
        cells.forEach(cell => {
            cell.textContent = '';
        });

        currentPlayer = 'X';
        gameWon = false;
        resultScreen.classList.add('hidden');
        newGameBtn.classList.add('hidden');
    }
});
